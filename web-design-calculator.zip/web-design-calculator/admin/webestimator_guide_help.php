<?php
	
?>
<div style="float:none" class="well-3 center-block-3 col-md-4-3">
<h3>Help - User Guide</h3>

== <b>Description</b> ==
<p>
Thank you for installing Web Design Calculator. Please visit [demo](https://walexconcepts.com/wordpress/plugin-webestimator//).
</p>


Free Version features:
<p>
<ul>
<li>* Web Design Calculator looks responsive on any device.</li>
<li>* No backend or admin functionality .</li>
<li>* You cannot adjust the features according to your budget..</li>
<li>* Coding skills NOT required.</li>
<li>* Theme modifications NOT required.</li>
<li>* No animation circular progress bar.</li>
<li>* You cannot go beyond 3 steps to save and finish.</li>
<li>* You cannot change total currency symbol.</li>

</ul>
</p>
All

Premium Features:
<p>
<ul>
<li>* Web Design Calculator looks responsive on any device.</li>
<li>* Add backend or admin functionality .</li>
<li>* You can adjust the features according to your budget..</li>
<li>* Coding skills NOT required.</li>
<li>* Theme modifications NOT required.</li>
<li>* Add animation circular progress bar.</li>
<li>* You can go beyond 3 steps to save and finish.</li>
<li>* You can change total currency symbol.</li>
</ul>
</p>
